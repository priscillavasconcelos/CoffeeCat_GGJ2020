﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RepairTool : MonoBehaviour
{
    public bool beenTaken = false;
}
